package course1.section1.video_1_9

case class HttpRequest(id: String)
